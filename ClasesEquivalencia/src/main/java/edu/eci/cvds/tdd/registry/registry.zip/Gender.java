package edu.eci.cvds.tdd.registry;

public enum Gender {

    MALE, FEMALE, UNIDENTIFIED;
}