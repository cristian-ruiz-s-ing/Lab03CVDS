package edu.eci.cvds.tdd.registry;

public enum RegisterResult {
        DEAD, UNDERAGE, INVALID_AGE, VALID, DUPLICATED
}
